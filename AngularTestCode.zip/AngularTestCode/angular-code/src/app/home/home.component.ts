import { Component} from '@angular/core';
import { Subscription } from 'rxjs';
import {UserService } from '../services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  currentUser:any;
  currentUserSubscription: Subscription;

  constructor(
      private userService: UserService      
  ) {
       this.currentUserSubscription = this.userService.currentUser.subscribe(user => {
          this.currentUser = user;
      }); 
  }
}
