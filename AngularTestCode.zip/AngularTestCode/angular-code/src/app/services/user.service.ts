import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;
  apiUrl = "localhost:3000";
  constructor(private http: HttpClient) {  
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser') || '{}'));
    this.currentUser = this.currentUserSubject.asObservable(); 
  }
  public get currentUserValue(): User {
    return this.currentUserSubject.value; 
  } 
  getAll() {
    return this.http.get<User[]>(`${this.apiUrl}/user`);
  }

  register(user: User) {
      return this.http.post(`${this.apiUrl}/user/register`, user);
  }

  login(username: string, password: string) {        
    return this.http.post<any>(`${this.apiUrl}/user/login`, { username, password })
        .pipe(map(user => {
          console.log(user)
            if (user) {
                localStorage.setItem('currentUser', JSON.stringify(user));
                this.currentUserSubject.next(user);
            }
            return user;
        }));
  } 

  logout() {
      localStorage.removeItem('currentUser');
      this.currentUserSubject.next(null!);
  } 
}
