
const express = require('express');

const router = express.Router();

let data = [
    { id: 1, username: 'sandeep',  password: 'sand123456', firstName: 'sandeep', lastName: 'j', address:'Bangalore'},
    { id: 2, username: 'sandeep1', password: 'sand123456', firstName: 'sandeep', lastName: 'j', address:'Bangalore'},
    { id: 3, username: 'sandeep2', password: 'sand123456', firstName: 'sandeep', lastName: 'j', address:'Bangalore'},
    { id: 4, username: 'sandeep3', password: 'sand123456', firstName: 'sandeep', lastName: 'j', address:'Bangalore'},
    { id: 5, username: 'sandeep4', password: 'sand123456', firstName: 'sandeep', lastName: 'j', address:'Bangalore'},
];


router.get('/', function (req, res) {
    res.status(200).json(data);
});


router.get('/:id', function (req, res) {   
    let found = data.find(function (item) {
        return item.id === parseInt(req.params.id);
    });
   
    if (found) {
        res.status(200).json(found);
    } else {
        res.sendStatus(404);
    }
});


router.post('/register', function (req, res) {
    
    let itemIds = data.map(item => item.id);
    
    let newId = itemIds.length > 0 ? Math.max.apply(Math, itemIds) + 1 : 1;    
    
    let newItem = {
        id: newId, 
        username: req.body.username, 
        password: req.body.password, 
        firstName: req.body.firstName, 
        lastName: req.body.lastName,
		address:req.body.address
    };
   
    data.push(newItem);
   
    res.status(201).json(newItem);
});
router.post('/login', function (req, res) {  
    
    let found = data.find(function (item) {
        return item.username === req.body.username && item.password === req.body.password;
    });
   
    if (found) {
        res.status(200).json(found);
    } else {
        res.sendStatus(404);
    }
});
 
module.exports = router;