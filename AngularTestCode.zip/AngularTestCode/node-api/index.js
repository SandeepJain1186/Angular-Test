const http = require('http');
const express = require('express');
var cors = require('cors');

const usersRouter = require('./routes/user');

const app = express();

app.use(express.json());

const corsOptions ={
    origin:'http://localhost:3000', 
    credentials:true,           
    optionSuccessStatus:200
}
app.use(cors(corsOptions));

app.use('/user', usersRouter);

app.use('/', function(req, res) {
    res.send('user api works :-)');
});

const server = http.createServer(app);
const port = 3000;
server.listen(port);
